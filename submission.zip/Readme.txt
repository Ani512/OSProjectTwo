Running my Program - 

IDE - Recommended IDE is VSCode

Command Line -

python main.py

    OR 

python3 main.py

[I recommend using Python 3]
